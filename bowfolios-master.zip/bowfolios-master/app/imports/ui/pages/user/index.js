import './profile-page.html';
import './profile-page';
